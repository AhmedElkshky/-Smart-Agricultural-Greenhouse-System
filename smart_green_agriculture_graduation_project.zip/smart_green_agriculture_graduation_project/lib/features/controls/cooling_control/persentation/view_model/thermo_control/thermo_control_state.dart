part of 'thermo_control_cubit.dart';

@immutable
abstract class ThermoControlState {}

class ThermoControlInitial extends ThermoControlState {}
class SuccessThermoControlTypeReturn extends ThermoControlState {}
class SuccessGetThermoControlTypeReturn extends ThermoControlState {}
