part of 'check_user_type_cubit.dart';

@immutable
abstract class CheckUserTypeState {}

class CheckUserTypeInitial extends CheckUserTypeState {}
class CheckUserState extends CheckUserTypeState {}
