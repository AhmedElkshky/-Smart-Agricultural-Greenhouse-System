part of 'pick_user_image_cubit.dart';

@immutable
abstract class PickUserImageState {}

class PickUserImageInitial extends PickUserImageState {}
class PickImageSuccess extends PickUserImageState{}