part of 'buzzer_control_cubit.dart';

@immutable
abstract class BuzzerControlState {}

class BuzzerControlInitial extends BuzzerControlState {}
class SuccessBuzzerControlReturn extends BuzzerControlState {}
class SuccessGetbuzzerControlReturn extends BuzzerControlState {}
