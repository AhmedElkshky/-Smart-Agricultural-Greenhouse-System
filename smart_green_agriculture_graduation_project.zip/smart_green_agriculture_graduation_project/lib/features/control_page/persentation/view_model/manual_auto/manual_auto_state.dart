part of 'manual_auto_cubit.dart';

@immutable
abstract class ManualAutoState {}

class ManualAutoInitial extends ManualAutoState {}
class SuccessControlTypeReturn extends ManualAutoState{}
class SuccessGetControlTypeReturn extends ManualAutoState{}