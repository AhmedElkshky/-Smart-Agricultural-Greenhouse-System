import 'package:flutter/material.dart';

class DetectPlanetPage extends StatelessWidget {
  const DetectPlanetPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:
      Center(child: Text('detect planet page')),
    );
  }
}
