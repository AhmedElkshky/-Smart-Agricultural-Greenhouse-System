part of 'pick_green_house_photo_cubit.dart';

@immutable
abstract class PickGreenHousePhotoState {}

class PickGreenHousePhotoInitial extends PickGreenHousePhotoState {}
class PickGreenHouseImageSuccess extends PickGreenHousePhotoState {}
